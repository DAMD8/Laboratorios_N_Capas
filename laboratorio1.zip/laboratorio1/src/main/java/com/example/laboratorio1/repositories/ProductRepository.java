package com.example.laboratorio1.repositories;

import com.example.laboratorio1.common.ProductList;
import com.example.laboratorio1.domain.model.HyruleProducts;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class ProductRepository {
    private final ProductList productList;

    public List<HyruleProducts> findAll() {
        return productList.getProducts();
    }
}
