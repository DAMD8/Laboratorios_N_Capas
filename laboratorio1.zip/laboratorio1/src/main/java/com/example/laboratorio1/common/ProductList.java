package com.example.laboratorio1.common;

import com.example.laboratorio1.domain.model.HyruleProducts;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ProductList {
    private final List<HyruleProducts> products;

    public ProductList() {
        this.products = new ArrayList<>();

        this.products.add(HyruleProducts.builder()
                .id(1)
                .nombre("Diamante")
                .precio(850)
                .categoria("Materiales y Tesoros")
                .ubicacion("Minas de Hyrule")
                .rareza("Epico")
                .build());
        this.products.add(HyruleProducts.builder()
                .id(2)
                .nombre("Fragmento de estrella")
                .precio(500)
                .categoria("Materiales y Tesoros")
                .ubicacion("Hyrule")
                .rareza("Legendario")
                .build());
        this.products.add(HyruleProducts.builder()
                .id(3)
                .nombre("Trufa Vital")
                .precio(6)
                .categoria("Consumibles y Cocina")
                .ubicacion("Montaña Satori")
                .rareza("Raro")
                .build());
        this.products.add(HyruleProducts.builder()
                .id(4)
                .nombre("Manzana Dorada")
                .precio(12)
                .categoria("Consumibles y Cocina")
                .ubicacion("Pantano de Lanayru")
                .rareza("Poco Común")
                .build());
        this.products.add(HyruleProducts.builder()
                .id(5)
                .nombre("Flecha Ancestral")
                .precio(90)
                .categoria("Equipamiento y Combate")
                .ubicacion("Laboratorio de Akkala")
                .rareza("Raro")
                .build());
        this.products.add(HyruleProducts.builder()
                .id(6)
                .nombre("Escudo Hyliano")
                .precio(3000)
                .categoria("Equipamiento y Combate")
                .ubicacion("Castillo de Hyrule")
                .rareza("Legendario")
                .build());
        this.products.add(HyruleProducts.builder()
                .id(7)
                .nombre("Rubi")
                .precio(210)
                .categoria("Materiales y Tesoros")
                .ubicacion("Montaña de la Muerte")
                .rareza("Raro")
                .build());
        this.products.add(HyruleProducts.builder()
                .id(8)
                .nombre("Ambar")
                .precio(30)
                .categoria("Materiales y Tesoros")
                .ubicacion("Todo Hyrule")
                .rareza("Común")
                .build());
    }
    public List<HyruleProducts> getProducts() {
        return products;
    }
}
