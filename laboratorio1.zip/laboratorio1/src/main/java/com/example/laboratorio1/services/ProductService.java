package com.example.laboratorio1.services;

import com.example.laboratorio1.domain.model.HyruleProducts;
import com.example.laboratorio1.repositories.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductService {
    private final ProductRepository productRepository;

    public List<HyruleProducts> getAllProducts() {
        return productRepository.findAll();
    }

    public List<HyruleProducts> obtenerOrdenadosPorPrecio() {
        return productRepository.findAll().stream()
                .sorted(Comparator.comparingInt(HyruleProducts::getPrecio).reversed())
                .collect(Collectors.toList());
    }
    public HyruleProducts obtenerMasCaro() {
        return productRepository.findAll().stream()
                .max(Comparator.comparingInt(HyruleProducts::getPrecio))
                .orElse(null);
    }

    public List<HyruleProducts> obtenerLegendarios() {
        return productRepository.findAll().stream()
                .filter(p -> "Legendario".equalsIgnoreCase(p.getRareza()))
                .collect(Collectors.toList());
    }

    public List<String> obtenerUbicacionesUnicas() {
        return productRepository.findAll().stream()
                .map(HyruleProducts::getUbicacion)
                .distinct()
                .collect(Collectors.toList());
    }
}
