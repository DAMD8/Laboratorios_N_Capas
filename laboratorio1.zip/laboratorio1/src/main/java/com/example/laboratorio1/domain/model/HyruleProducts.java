package com.example.laboratorio1.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class HyruleProducts {
    private int id;
    private String nombre;
    private int precio;
    private String categoria;
    private String ubicacion;
    private String rareza;
}
